/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatapp;


/**
 *
 * @author USER
 */
import javax.swing.JOptionPane;

public class ChatApp {

    private static int messageCount = 0;

    public static void main(String[] args) {
        while (true) {
            String[] mainOptions = {
                "Register",
                "Login",
                "Send a Message",
                "View Sent Messages",
                "Search Message",
                "Delete Message",
                "View Report",
                "Exit"
            };

            int choice = JOptionPane.showOptionDialog(
                null,
                "Welcome to Developers Quick App \nSelect an option:",
                "Main Menu",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE,
                null,
                mainOptions,
                mainOptions[0]
            );

            switch (choice) {
                case 0:
                    performRegistration();
                    break;
                case 1:
                    performLogin();
                    break;
                case 2:
                    sendMessage();
                    break;
                case 3:
                    viewSentMessages();
                    break;
                case 4:
                    searchMessage();
                    break;
                case 5:
                    deleteMessage();
                    break;
                case 6:
                    Message.displayReport();
                    break;
                case 7:
                case JOptionPane.CLOSED_OPTION:
                    JOptionPane.showMessageDialog(null, "Goodbye!");
                    System.exit(0);
                    break;
            }
        }
    }

    private static void performRegistration() {
        String name = JOptionPane.showInputDialog("Enter your name:");
        String surname = JOptionPane.showInputDialog("Enter your surname:");
        String cell = JOptionPane.showInputDialog("Enter your cell number (start with +27):");
        String username = JOptionPane.showInputDialog("Choose a username:");
        String password = JOptionPane.showInputDialog("Choose a password (min 8 characters, 1 digit, 1 uppercase):");

        Login user = new Login();
        String response = user.registerUser(name, surname, cell, username, password);
        JOptionPane.showMessageDialog(null, response);
    }

    private static void performLogin() {
        String username = JOptionPane.showInputDialog("Enter your username:");
        String password = JOptionPane.showInputDialog("Enter your password:");

        Login user = new Login();
        boolean response = user.loginUser(username, password);
        JOptionPane.showMessageDialog(null, response);
    }

    private static void sendMessage() {
        String recipient = JOptionPane.showInputDialog("Enter recipient cell number using the south african code +27");
        if (recipient == null) return;

        String message = JOptionPane.showInputDialog("Enter your message (max 250 characters):");
        if (message == null) return;

        if (message.length() > 250 || message.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Message exceeds 250 charecters.please reduce the side");
            return;
        }

        messageCount++;
        Message msg = new Message(recipient, message, messageCount);
        if (!msg.checkRecipientCell()) {
            JOptionPane.showMessageDialog(null, "Cell umber is incorrectly formatted or does not contain an internation code.please try again");
            return;
        }

        String result = msg.SentMessage();
        JOptionPane.showMessageDialog(null, result);
    }

    private static void viewSentMessages() {
        String messages = Message.printMessages();
        if (messages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages have been sent.");
        } else {
            JOptionPane.showMessageDialog(null, messages);
        }
    }

    private static void searchMessage() {
        String[] searchOptions = { "Search by Message ID", "Search by Recipient" };
        int option = JOptionPane.showOptionDialog(
            null,
            "Choose search method:",
            "Search Message",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.PLAIN_MESSAGE,
            null,
            searchOptions,
            searchOptions[0]
        );

        if (option == 0) {
            String id = JOptionPane.showInputDialog("Enter Message ID:");
            if (id != null) {
                Message.searchByMessageID(id);
            }
        } else if (option == 1) {
            String recipient = JOptionPane.showInputDialog("Enter Recipient Cell Number:");
            if (recipient != null) {
                Message.searchByRecipient(recipient);
            }
        }
    }

    private static void deleteMessage() {
        String hash = JOptionPane.showInputDialog("Enter message hash to delete:");
        if (hash != null) {
            Message.deleteMessageByHash(hash);
        }
    }
}
/* reference3.author = Brown, A.
reference3.year = 2021
reference3.title = Java for Beginners
reference3.publisher = Learning Hub
reference3.location = San Francisco*/
