/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp;

/**
 *
 * @author Zandile
 */
/*reference4.author = Taylor, R. & Green, S.
reference4.year = 2019
reference4.title = Object-Oriented Programming in Java
reference4.publisher = Code Masters
reference4.location = Chicago
*/

import java.util.*;
import java.util.regex.Pattern;
import java.io.*;
import javax.swing.JOptionPane;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;

public class Message {

    private String messageID;
    private int numMessagesSent;
    private String recipient;
    private String message;
    private String messageHash;

    private static List<Message> sentMessages = new ArrayList<>();
    private static List<Message> disregardedMessages = new ArrayList<>();
    private static List<Message> storedMessages = new ArrayList<>();
    private static List<String> messageHashes = new ArrayList<>();
    private static List<String> messageIDs = new ArrayList<>();

    public Message() {
        this.messageID = "";
        this.numMessagesSent = 0;
        this.recipient = "";
        this.message = "";
        this.messageHash = "";
    }

    public Message(String recipient, String message, int numMessagesSent) {
        this.messageID = generateMessageID();
        this.numMessagesSent = numMessagesSent;
        this.recipient = recipient;
        this.message = message;
        this.messageHash = createMessageHash();
        messageHashes.add(this.messageHash);
        messageIDs.add(this.messageID);
    }

    private String generateMessageID() {
        Random rand = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            sb.append(rand.nextInt(10));
        }
        return sb.toString();
    }

    public boolean checkMessageID() {
        return this.messageID.length() <= 10;
    }

    public boolean checkRecipientCell() {
        if (recipient == null) return false;
        String regex = "^\\+\\d{1,3}\\d{7,10}$";
        return Pattern.matches(regex, recipient);
    }

    public String createMessageHash() {
        String firstTwo = messageID.substring(0, 2);
        String numStr = Integer.toString(numMessagesSent);
        String[] words = message.split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
        return (firstTwo + ":" + numStr + ":" + firstWord + lastWord).toUpperCase();
    }

    public String SentMessage() {
        String[] options = { "Send Message", "Disregard Message", "Store Message to send later" };
        int choice = JOptionPane.showOptionDialog(
            null,
            "Choose an option for the message:\n\n" + message,
            "Message Options",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            options[0]
        );

        switch (choice) {
            case 0:
                sentMessages.add(this);
                return "Message successfully sent.";
            case 1:
                disregardedMessages.add(this);
                return "Message disregarded.";
            case 2:
                storedMessages.add(this);
                storeMessage();
                return "Message successfully stored.";
            default:
                return "No action taken.";
        }
    }

    public void storeMessage() {
        Gson gson = new Gson();
        try (FileWriter writer = new FileWriter("messages.json")) {
            gson.toJson(storedMessages, writer);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error in storing messages: " + e.getMessage());
        }
    }

    public static void readStoredMessages() {
        Gson gson = new Gson();
        try (FileReader reader = new FileReader("messages.json")) {
            Type listType = new TypeToken<ArrayList<Message>>(){}.getType();
            List<Message> messagesFromFile = gson.fromJson(reader, listType);
            if (messagesFromFile != null) {
                storedMessages = messagesFromFile;
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading stored messages: " + e.getMessage());
        }
    }

    public static String printMessages() {
        StringBuilder sb = new StringBuilder();
        for (Message msg : sentMessages) {
            sb.append("MessageID: ").append(msg.messageID).append(", ");
            sb.append("Message Hash: ").append(msg.messageHash).append(", ");
            sb.append("Recipient: ").append(msg.recipient).append(", ");
            sb.append("Message: ").append(msg.message).append("\n");
        }
        return sb.toString();
    }

    public static int returnTotalMessages() {
        return sentMessages.size();
    }

    public static void displaySenderRecipient() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages.");
            return;
        }

        StringBuilder sb = new StringBuilder("Sender and Recipient of all sent messages:\n\n");
        for (Message msg : sentMessages) {
            sb.append("Sender: ").append(msg.messageID).append(", Recipient: ").append(msg.recipient).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    public static void displayLongestMessage() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages.");
            return;
        }

        Message longest = sentMessages.get(0);
        for (Message msg : sentMessages) {
            if (msg.message.length() > longest.message.length()) {
                longest = msg;
            }
        }
        JOptionPane.showMessageDialog(null, "Longest sent message:\n\n" + longest.message);
    }

    public static void searchByMessageID(String id) {
        for (Message msg : sentMessages) {
            if (msg.messageID.equals(id)) {
                JOptionPane.showMessageDialog(null,
                    "Message found:\n\nRecipient: " + msg.recipient + "\nMessage: " + msg.message);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message ID not found.");
    }

    public static void searchByRecipient(String recipient) {
        StringBuilder sb = new StringBuilder();
        boolean found = false;
        for (Message msg : sentMessages) {
            if (msg.recipient.equals(recipient)) {
                sb.append("Message to ").append(recipient).append(": ").append(msg.message).append("\n");
                found = true;
            }
        }
        if (found) {
            JOptionPane.showMessageDialog(null, sb.toString());
        } else {
            JOptionPane.showMessageDialog(null, "No messages found for recipient: " + recipient);
        }
    }

    public static void deleteMessageByHash(String hash) {
        for (int i = 0; i < sentMessages.size(); i++) {
            if (sentMessages.get(i).messageHash.equals(hash)) {
                JOptionPane.showMessageDialog(null, 
                    "Message \"" + sentMessages.get(i).message + "\" successfully deleted.");
                sentMessages.remove(i);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message hash not found.");
    }

    public static void displayReport() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages sent.");
            return;
        }

        StringBuilder sb = new StringBuilder("Report of all sent messages:\n\n");
        for (Message msg : sentMessages) {
            sb.append("Message Hash: ").append(msg.messageHash).append("\n");
            sb.append("Recipient: ").append(msg.recipient).append("\n");
            sb.append("Message: ").append(msg.message).append("\n");
            sb.append("-------------------------\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    // Getters
    public String getMessageID() {
        return messageID;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessage() {
        return message;
    }

    public String getMessageHash() {
        return messageHash;
    }
}
    

